This is a web project done by the students of BSc Electronics Technology of the University of Eastern Africa, Baraton.

It is a realtime chat application developed by Spring Boot and WebSocket. The application allows users to join and leave chat rooms in real time communcation between server and clients.

Ensure you can first compile java applications on your machine before downloading this project.
In your editor of choice(We recommend Vs Code because of its simplicity) open the project. After opening the project run it by keying the combination ctrl + f5 or by clicking the run option in the menu and clicking run without debugging.
Ensure you have extensions for maven and springboot tools enabled.

Proceed to your browser and type  "localhost:8080" in you address bar ans click enter. Enter your name and use "password" as your password. This will let you into the chatroom.

To test the capability of many users joining, open the same url in another browser and login using another name.

In your code, proceed to the file ChatMessage.java that is in the package "com.electronics.Chato.model" for further directions.