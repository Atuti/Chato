package com.electronics.Chato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatoApplication.class, args);
	}

}
