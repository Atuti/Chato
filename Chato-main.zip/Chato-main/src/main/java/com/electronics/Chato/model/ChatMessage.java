package com.electronics.Chato.model;

import lombok.*;

// import java.nio.file.FileStore;

/*
 * comment out the @Getter, @Setter, @AllArgsConstructor, and @NoArgsConstructor
 * and then 1) write two constructors one without arguments and another with three arguments
 * 2) for the three variables in the ChatMessage class generate setters
 * 3) for the three variables generate getters
 * The work is complete only of the code will run after the changes have been made.
 */


 public class ChatMessage {

    private String sender;
    private String message;
    private long timestamp;

    // Constructor without arguments
    public ChatMessage() {
        // Default constructor
    }

    // Constructor with three arguments
    public ChatMessage(String sender, String message, long timestamp) {
        this.sender = sender;
        this.message = message;
        this.timestamp = timestamp;
    }

    // Getter for sender
    public String getSender() {
        return sender;
    }

    // Setter for sender
    public void setSender(String sender) {
        this.sender = sender;
    }

    // Getter for message
    public String getMessage() {
        return message;
    }

    // Setter for message
    public void setMessage(String message) {
        this.message = message;
    }

    // Getter for timestamp
    public long getTimestamp() {
        return timestamp;
    }

    // Setter for timestamp
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }



    public enum MessageType{
        CHAT, LEAVE, JOIN
    }
}
